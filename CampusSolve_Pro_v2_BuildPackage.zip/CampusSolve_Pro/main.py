"""CampusSolve Pro - Student Performance Analyzer (entry point).

Usage:
    python main.py              start the desktop application
    python main.py --summary    print a class summary in the terminal (no GUI)
    python main.py --version    show the version
"""
from __future__ import annotations

import sys

from campussolve import APP_NAME, __version__


def print_summary() -> int:
    from campussolve import core
    store = core.StudentStore()
    try:
        students = store.load()
    except core.DataFileError as exc:
        print(f"Could not load {store.path}: {exc}")
        return 1
    if not students:
        print("No student records yet. Start the app and add some (or load the sample data).")
        return 0
    summary = core.class_summary(students)
    print(f"{APP_NAME} - class summary ({summary['count']} students)")
    print(f"  Class average : {summary['average']:.2f}%   Median: {summary['median']:.2f}%")
    print(f"  Pass rate     : {summary['pass_rate']:.1f}%   Needing attention: {summary['attention']}")
    print(f"  Topper        : {summary['topper']}\n")
    print(f"{'Rank':<6}{'Roll':<10}{'Name':<24}{'Avg %':>8}  Grade")
    for rank, s in core.rank_students(students):
        print(f"{rank:<6}{s['roll']:<10}{s['name']:<24}{s['average']:>8.2f}  {s['grade']}")
    return 0


def main(argv: list[str]) -> int:
    if "--version" in argv:
        print(f"{APP_NAME} {__version__}")
        return 0
    if "--summary" in argv:
        return print_summary()
    try:
        from campussolve.gui import run
    except ImportError as exc:
        print("Tkinter is not available:", exc)
        print("Windows/macOS: reinstall Python from python.org and keep 'tcl/tk' ticked.")
        print("Ubuntu/Debian: sudo apt install python3-tk")
        return 1
    run()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
