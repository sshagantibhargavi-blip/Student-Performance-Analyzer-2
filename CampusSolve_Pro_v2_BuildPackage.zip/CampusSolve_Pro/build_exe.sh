#!/usr/bin/env bash
# Builds a single-file executable for Linux/macOS: dist/CampusSolvePro
set -e
cd "$(dirname "$0")"
python3 -m pip install --upgrade pyinstaller
python3 -m PyInstaller --noconfirm --clean --onefile --windowed --name CampusSolvePro main.py
echo "Done: dist/CampusSolvePro"
