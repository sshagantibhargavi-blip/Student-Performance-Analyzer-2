"""Tkinter user interface for CampusSolve Pro."""
from __future__ import annotations

import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import APP_NAME, __version__, core

BG = "#f4f7fb"
INK = "#14213d"
MUTED = "#64748b"
ACCENT = "#315efb"
GRADE_COLORS = {"A": "#067647", "B": "#1d4ed8", "C": "#475569", "D": "#b45309", "F": "#b42318"}
FILTERS = ["All grades", "A", "B", "C", "D", "F", "Needs attention"]
MAX_UNDO = 20


# --------------------------------------------------------------------------
# Generic bar-chart helper (drawn on a Canvas, no third-party packages)
# --------------------------------------------------------------------------
def draw_bar_chart(canvas: tk.Canvas, labels, values, ymax, ticks, color, fmt="{:.1f}",
                   bar_colors=None):
    canvas.delete("all")
    width = max(canvas.winfo_width(), 420)
    height = max(canvas.winfo_height(), 260)
    left, right, top, bottom = 50, 20, 30, 42
    base_y = height - bottom
    plot_h = base_y - top
    canvas.create_line(left, base_y, width - right, base_y, fill="#94a3b8")
    for tick in ticks:
        y = base_y - plot_h * tick / ymax
        canvas.create_line(left, y, width - right, y, fill="#e5eaf2", dash=(2, 3))
        canvas.create_text(left - 8, y, text=str(tick), fill=MUTED, anchor="e", font=("Segoe UI", 8))
    gap = (width - left - right) / max(len(labels), 1)
    bar_w = min(70, gap * 0.55)
    for i, (label, value) in enumerate(zip(labels, values)):
        x = left + gap * (i + 0.5)
        y = base_y - plot_h * min(value, ymax) / ymax
        fill = bar_colors[i] if bar_colors else color
        canvas.create_rectangle(x - bar_w / 2, y, x + bar_w / 2, base_y, fill=fill, outline="")
        canvas.create_text(x, y - 11, text=fmt.format(value), fill="#243247", font=("Segoe UI", 9, "bold"))
        canvas.create_text(x, base_y + 16, text=label, fill="#475569", font=("Segoe UI", 8))


# --------------------------------------------------------------------------
# Add / edit dialog with live preview
# --------------------------------------------------------------------------
class StudentDialog(tk.Toplevel):
    def __init__(self, parent, title="Add Student", student=None):
        super().__init__(parent)
        self.title(title)
        self.configure(bg=BG)
        self.resizable(False, False)
        self.result = None
        self.transient(parent)
        self.vars = {"name": tk.StringVar(value=student["name"] if student else ""),
                     "roll": tk.StringVar(value=student["roll"] if student else "")}
        for subject in core.SUBJECTS:
            self.vars[subject] = tk.StringVar(
                value=f"{student['marks'][subject]:g}" if student else "")
            self.vars[subject].trace_add("write", lambda *_: self.update_preview())
        self.preview = tk.StringVar()

        body = ttk.Frame(self, padding=20)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text="Student information", style="Section.TLabel").grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))
        fields = [("Student name", "name"), ("Roll number", "roll")] + \
                 [(f"{s} (0-100)", s) for s in core.SUBJECTS]
        first_entry = None
        for row, (label, key) in enumerate(fields, 1):
            ttk.Label(body, text=label).grid(row=row, column=0, sticky="w", padx=(0, 18), pady=5)
            entry = ttk.Entry(body, textvariable=self.vars[key], width=28)
            entry.grid(row=row, column=1, sticky="ew", pady=5)
            first_entry = first_entry or entry
        ttk.Label(body, textvariable=self.preview, style="Sub.TLabel").grid(
            row=len(fields) + 1, column=0, columnspan=2, sticky="w", pady=(10, 0))
        buttons = ttk.Frame(body)
        buttons.grid(row=len(fields) + 2, column=0, columnspan=2, sticky="e", pady=(15, 0))
        ttk.Button(buttons, text="Cancel", command=self.destroy).pack(side="right", padx=(8, 0))
        ttk.Button(buttons, text="Save student", style="Accent.TButton",
                   command=self.submit).pack(side="right")
        self.bind("<Return>", lambda _e: self.submit())
        self.bind("<Escape>", lambda _e: self.destroy())
        self.update_preview()
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_width()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_height()) // 2
        self.geometry(f"+{max(0, x)}+{max(0, y)}")
        try:
            self.wait_visibility()
            self.grab_set()
        except tk.TclError:
            pass
        first_entry.focus_set()

    def update_preview(self):
        try:
            marks = [core.parse_mark(self.vars[s].get(), s) for s in core.SUBJECTS]
        except core.ValidationError:
            self.preview.set("Live preview appears when all five marks are valid (0-100).")
            return
        total = sum(marks)
        average = total / len(marks)
        self.preview.set(f"Preview:  total {total:.1f} / {core.MAX_TOTAL:.0f}   |   "
                         f"average {average:.2f}%   |   grade {core.grade_for(average)}")

    def submit(self):
        try:
            self.result = core.normalize_record({
                "name": self.vars["name"].get(), "roll": self.vars["roll"].get(),
                "marks": {s: self.vars[s].get() for s in core.SUBJECTS}})
        except core.ValidationError as exc:
            messagebox.showwarning("Please check the form", str(exc), parent=self)
            return
        self.destroy()


# --------------------------------------------------------------------------
# Main application window
# --------------------------------------------------------------------------
class CampusSolveApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} | Student Performance Analyzer")
        self.geometry("1180x740")
        self.minsize(980, 640)
        self.configure(bg=BG)
        self.store = core.StudentStore()
        self.undo_stack: list[list[dict]] = []
        self.students: list[dict] = []
        self.search_var = tk.StringVar()
        self.filter_var = tk.StringVar(value=FILTERS[0])
        self.status_var = tk.StringVar(value="Ready")
        self.sort_col, self.sort_reverse = "rank", False
        self.load_data()
        self.setup_styles()
        self.build_menu()
        self.build_ui()
        self.bind_shortcuts()
        self.refresh()

    # ----- start-up -----
    def load_data(self):
        try:
            self.students = self.store.load()
        except core.DataFileError as exc:
            copy = self.store.quarantine()
            note = f"\n\nA copy of the unreadable file was saved as:\n{copy}" if copy else ""
            self.students = []
            self.after_idle(lambda: messagebox.showerror(
                "Data file problem",
                f"Could not safely load students.json.\n\n{exc}{note}\n\n"
                "The app will start with an empty list."))

    def setup_styles(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background=BG)
        style.configure("TLabel", background=BG, foreground="#243247", font=("Segoe UI", 10))
        style.configure("Title.TLabel", font=("Segoe UI", 22, "bold"), foreground=INK)
        style.configure("Sub.TLabel", font=("Segoe UI", 10), foreground=MUTED)
        style.configure("Section.TLabel", font=("Segoe UI", 13, "bold"), foreground=INK)
        style.configure("Card.TFrame", background="#ffffff", relief="flat")
        style.configure("CardTitle.TLabel", background="#ffffff", foreground=MUTED,
                        font=("Segoe UI", 9, "bold"))
        style.configure("CardValue.TLabel", background="#ffffff", foreground=INK,
                        font=("Segoe UI", 21, "bold"))
        style.configure("Accent.TButton", background=ACCENT, foreground="#ffffff",
                        padding=(13, 8), font=("Segoe UI", 9, "bold"))
        style.map("Accent.TButton", background=[("active", "#244bd1")])
        style.configure("Treeview", rowheight=30, font=("Segoe UI", 9),
                        background="#ffffff", fieldbackground="#ffffff")
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#e9eef8",
                        foreground="#243247", padding=8)

    def build_menu(self):
        bar = tk.Menu(self)
        file_menu = tk.Menu(bar, tearoff=False)
        file_menu.add_command(label="Add student", accelerator="Ctrl+N", command=self.add_student)
        file_menu.add_separator()
        file_menu.add_command(label="Import students from CSV...", command=self.import_csv)
        file_menu.add_command(label="Export ranked report (CSV)...", accelerator="Ctrl+S",
                              command=self.export_csv)
        file_menu.add_command(label="Back up data (JSON)...", command=self.backup_json)
        file_menu.add_separator()
        file_menu.add_command(label="Load sample data", command=self.load_sample)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.destroy)
        bar.add_cascade(label="File", menu=file_menu)

        edit_menu = tk.Menu(bar, tearoff=False)
        edit_menu.add_command(label="Edit selected", accelerator="Ctrl+E", command=self.edit_student)
        edit_menu.add_command(label="Delete selected", accelerator="Del", command=self.delete_student)
        edit_menu.add_command(label="Undo last change", accelerator="Ctrl+Z", command=self.undo)
        bar.add_cascade(label="Edit", menu=edit_menu)

        view_menu = tk.Menu(bar, tearoff=False)
        view_menu.add_command(label="Report card", accelerator="Ctrl+R", command=self.show_report_card)
        view_menu.add_command(label="Rankings", command=self.show_rankings)
        view_menu.add_command(label="Analytics dashboard", accelerator="Ctrl+D",
                              command=self.show_analytics)
        bar.add_cascade(label="View", menu=view_menu)

        help_menu = tk.Menu(bar, tearoff=False)
        help_menu.add_command(label="Grading scale", command=self.show_grading_scale)
        help_menu.add_command(label="Keyboard shortcuts", command=self.show_shortcuts)
        help_menu.add_command(label="About", command=self.show_about)
        bar.add_cascade(label="Help", menu=help_menu)
        self.config(menu=bar)

    def bind_shortcuts(self):
        self.bind("<Control-n>", lambda _e: self.add_student())
        self.bind("<Control-e>", lambda _e: self.edit_student())
        self.bind("<Control-s>", lambda _e: self.export_csv())
        self.bind("<Control-r>", lambda _e: self.show_report_card())
        self.bind("<Control-d>", lambda _e: self.show_analytics())
        self.bind("<Control-z>", lambda _e: None if self.is_typing() else self.undo())
        self.bind("<Control-f>", lambda _e: (self.search_entry.focus_set(), "break")[1])
        self.bind("<Delete>", lambda _e: None if self.is_typing() else self.delete_student())
        self.bind("<Escape>", lambda _e: self.search_var.set(""))

    def is_typing(self) -> bool:
        """True when a text field has focus, so Delete/Ctrl+Z keep their editing meaning."""
        return isinstance(self.focus_get(), (tk.Entry, tk.Text, ttk.Entry, ttk.Combobox))

    def build_ui(self):
        header = ttk.Frame(self, padding=(24, 16, 24, 6))
        header.pack(fill="x")
        ttk.Label(header, text=APP_NAME, style="Title.TLabel").pack(anchor="w")
        ttk.Label(header, text="STUDENT PERFORMANCE ANALYZER  \u2022  Academic insights made simple",
                  style="Sub.TLabel").pack(anchor="w", pady=(3, 0))

        cards = ttk.Frame(self, padding=(24, 8))
        cards.pack(fill="x")
        self.card_values = {}
        for key, title in [("count", "TOTAL STUDENTS"), ("average", "CLASS AVERAGE"),
                           ("topper", "TOP PERFORMER"), ("pass", "PASS RATE"),
                           ("attention", "NEED ATTENTION")]:
            card = ttk.Frame(cards, style="Card.TFrame", padding=14)
            card.pack(side="left", fill="x", expand=True, padx=(0, 10))
            ttk.Label(card, text=title, style="CardTitle.TLabel").pack(anchor="w")
            value = ttk.Label(card, text="\u2014", style="CardValue.TLabel")
            value.pack(anchor="w", pady=(6, 0))
            self.card_values[key] = value

        toolbar = ttk.Frame(self, padding=(24, 10, 24, 4))
        toolbar.pack(fill="x")
        ttk.Button(toolbar, text="+ Add student", style="Accent.TButton",
                   command=self.add_student).pack(side="left")
        for text, command in [("Edit selected", self.edit_student),
                              ("Delete selected", self.delete_student),
                              ("Report card", self.show_report_card),
                              ("Rankings", self.show_rankings),
                              ("Analytics", self.show_analytics)]:
            ttk.Button(toolbar, text=text, command=command).pack(side="left", padx=(7, 0))
        ttk.Button(toolbar, text="Export CSV", command=self.export_csv).pack(side="right")
        ttk.Button(toolbar, text="Import CSV", command=self.import_csv).pack(side="right", padx=(0, 7))

        searchrow = ttk.Frame(self, padding=(24, 4, 24, 8))
        searchrow.pack(fill="x")
        ttk.Label(searchrow, text="Search:").pack(side="left")
        self.search_entry = ttk.Entry(searchrow, textvariable=self.search_var, width=30)
        self.search_entry.pack(side="left", padx=8)
        self.search_var.trace_add("write", lambda *_: self.refresh_table())
        ttk.Button(searchrow, text="Clear", command=lambda: self.search_var.set("")).pack(side="left")
        ttk.Label(searchrow, text="Filter:").pack(side="left", padx=(24, 6))
        combo = ttk.Combobox(searchrow, textvariable=self.filter_var, values=FILTERS,
                             state="readonly", width=16)
        combo.pack(side="left")
        combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh_table())
        ttk.Label(searchrow, text="Tip: click a column heading to sort; double-click a row to edit.",
                  style="Sub.TLabel").pack(side="right")

        table_frame = ttk.Frame(self, padding=(24, 0, 24, 8))
        table_frame.pack(fill="both", expand=True)
        self.columns = ("rank", "roll", "name", "total", "average", "grade", "status")
        self.headings = {"rank": "RANK", "roll": "ROLL NUMBER", "name": "STUDENT NAME",
                         "total": "TOTAL / 500", "average": "AVERAGE %", "grade": "GRADE",
                         "status": "STATUS"}
        widths = {"rank": 65, "roll": 130, "name": 280, "total": 120, "average": 120,
                  "grade": 80, "status": 150}
        self.tree = ttk.Treeview(table_frame, columns=self.columns, show="headings",
                                 selectmode="browse")
        for col in self.columns:
            self.tree.heading(col, text=self.headings[col], command=lambda c=col: self.sort_by(c))
            self.tree.column(col, width=widths[col], anchor="w" if col == "name" else "center")
        for letter, color in GRADE_COLORS.items():
            self.tree.tag_configure(f"grade_{letter}", foreground=color)
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.tree.bind("<Double-1>", lambda _e: self.edit_student())

        bottom = ttk.Frame(self, padding=(24, 2, 24, 10))
        bottom.pack(fill="x")
        ttk.Label(bottom, textvariable=self.status_var, style="Sub.TLabel").pack(side="left")
        ttk.Label(bottom, text=f"Data stored locally in {os.path.basename(self.store.path)}",
                  style="Sub.TLabel").pack(side="right")

    # ----- data helpers -----
    def flash(self, message: str):
        self.status_var.set(message)

    def commit(self, new_students: list[dict], message: str) -> bool:
        """Apply a change, persist it, and roll back in memory if saving fails."""
        previous = self.students
        self.students = new_students
        try:
            self.store.save(new_students)
        except OSError as exc:
            self.students = previous
            messagebox.showerror("Save failed", f"Could not save student records.\n{exc}")
            return False
        self.undo_stack.append(previous)
        del self.undo_stack[:-MAX_UNDO]
        self.refresh()
        self.flash(message)
        return True

    def undo(self):
        if not self.undo_stack:
            self.flash("Nothing to undo.")
            return
        previous = self.undo_stack.pop()
        current = self.students
        self.students = previous
        try:
            self.store.save(previous)
        except OSError as exc:
            self.students = current
            self.undo_stack.append(previous)
            messagebox.showerror("Undo failed", str(exc))
            return
        self.refresh()
        self.flash("Last change undone.")

    # ----- table -----
    def refresh(self):
        summary = core.class_summary(self.students)
        has = summary["count"] > 0
        self.card_values["count"].configure(text=str(summary["count"]))
        self.card_values["average"].configure(text=f"{summary['average']:.1f}%" if has else "\u2014")
        self.card_values["topper"].configure(text=(summary["topper"] or "\u2014")[:14])
        self.card_values["pass"].configure(text=f"{summary['pass_rate']:.0f}%" if has else "\u2014")
        self.card_values["attention"].configure(text=str(summary["attention"]) if has else "\u2014")
        self.refresh_table()

    def sort_by(self, column: str):
        if self.sort_col == column:
            self.sort_reverse = not self.sort_reverse
        else:
            self.sort_col, self.sort_reverse = column, False
        self.refresh_table()

    def _sort_key(self, row):
        rank, s = row
        keys = {"rank": (rank, s["name"].casefold()), "roll": s["roll"].casefold(),
                "name": s["name"].casefold(), "total": s["total"], "average": s["average"],
                "grade": core.GRADES.index(s["grade"]),
                "status": (core.needs_attention(s), s["average"])}
        return keys[self.sort_col]

    def refresh_table(self):
        selected = self.tree.selection()
        for item in self.tree.get_children():
            self.tree.delete(item)
        query = self.search_var.get().strip().casefold()
        wanted = self.filter_var.get()
        rows = core.rank_students(self.students)
        rows.sort(key=self._sort_key, reverse=self.sort_reverse)
        for rank, s in rows:
            if query and query not in s["name"].casefold() and query not in s["roll"].casefold():
                continue
            if wanted == "Needs attention" and not core.needs_attention(s):
                continue
            if wanted in core.GRADES and s["grade"] != wanted:
                continue
            status = "Needs attention" if core.needs_attention(s) else "On track"
            self.tree.insert("", "end", iid=s["roll"], tags=(f"grade_{s['grade']}",),
                             values=(rank, s["roll"], s["name"], f"{s['total']:.1f}",
                                     f"{s['average']:.2f}", s["grade"], status))
        for col in self.columns:
            arrow = (" \u25BC" if self.sort_reverse else " \u25B2") if col == self.sort_col else ""
            self.tree.heading(col, text=self.headings[col] + arrow)
        for item in selected:
            if self.tree.exists(item):
                self.tree.selection_set(item)
        self.flash(f"Showing {len(self.tree.get_children())} of {len(self.students)} student(s)")

    def selected_student(self, quiet=False):
        selected = self.tree.selection()
        if not selected:
            if not quiet:
                messagebox.showinfo("Select a student", "Please select a student record first.")
            return None
        return next((s for s in self.students if s["roll"] == selected[0]), None)

    # ----- CRUD -----
    def add_student(self):
        dialog = StudentDialog(self)
        self.wait_window(dialog)
        if not dialog.result:
            return
        if core.roll_exists(self.students, dialog.result["roll"]):
            messagebox.showwarning("Duplicate roll number",
                                   "A student with this roll number already exists.")
            return
        if self.commit(self.students + [dialog.result], f"Added {dialog.result['name']}."):
            self.tree.selection_set(dialog.result["roll"])
            self.tree.see(dialog.result["roll"])

    def edit_student(self):
        old = self.selected_student()
        if not old:
            return
        dialog = StudentDialog(self, "Edit Student", old)
        self.wait_window(dialog)
        if not dialog.result:
            return
        if core.roll_exists(self.students, dialog.result["roll"], exclude=old):
            messagebox.showwarning("Duplicate roll number",
                                   "Another student already uses this roll number.")
            return
        updated = [dialog.result if s is old else s for s in self.students]
        self.commit(updated, f"Updated {dialog.result['name']}.")

    def delete_student(self):
        student = self.selected_student()
        if not student:
            return
        if messagebox.askyesno("Confirm deletion",
                               f"Delete {student['name']} ({student['roll']})?\n"
                               "You can undo this with Ctrl+Z."):
            self.commit([s for s in self.students if s is not student],
                        f"Deleted {student['name']}. Press Ctrl+Z to undo.")

    # ----- secondary windows -----
    def show_report_card(self):
        student = self.selected_student()
        if not student:
            return
        text = core.report_card_text(student, self.students)
        win = tk.Toplevel(self)
        win.title(f"Report card - {student['name']}")
        win.geometry("520x540")
        win.configure(bg=BG)
        box = tk.Text(win, font=("Consolas", 10), bg="#ffffff", relief="flat", padx=16, pady=14)
        box.insert("1.0", text)
        box.configure(state="disabled")
        box.pack(fill="both", expand=True, padx=16, pady=(16, 8))
        row = ttk.Frame(win, padding=(16, 0, 16, 14))
        row.pack(fill="x")
        ttk.Button(row, text="Close", command=win.destroy).pack(side="right")
        ttk.Button(row, text="Save as text file...", style="Accent.TButton",
                   command=lambda: self.save_text(text, f"report_{student['roll']}.txt")
                   ).pack(side="right", padx=(0, 8))

    def save_text(self, text: str, initial: str):
        path = filedialog.asksaveasfilename(defaultextension=".txt", initialfile=initial,
                                            filetypes=[("Text files", "*.txt")])
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(text)
            self.flash(f"Saved {os.path.basename(path)}")
        except OSError as exc:
            messagebox.showerror("Save failed", str(exc))

    def show_rankings(self):
        win = tk.Toplevel(self)
        win.title("Student Rankings")
        win.geometry("680x470")
        win.configure(bg=BG)
        ttk.Label(win, text="Academic leaderboard", style="Title.TLabel").pack(anchor="w", padx=20, pady=16)
        tree = ttk.Treeview(win, columns=("rank", "name", "roll", "average", "grade"), show="headings")
        for col, label, width in [("rank", "RANK", 70), ("name", "STUDENT", 220),
                                  ("roll", "ROLL NUMBER", 130), ("average", "AVERAGE", 110),
                                  ("grade", "GRADE", 80)]:
            tree.heading(col, text=label)
            tree.column(col, width=width, anchor="center")
        tree.pack(fill="both", expand=True, padx=20, pady=(0, 8))
        for rank, s in core.rank_students(self.students):
            tree.insert("", "end", values=(rank, s["name"], s["roll"], f"{s['average']:.2f}%", s["grade"]))
        ttk.Label(win, text="Students with equal averages share the same rank.",
                  style="Sub.TLabel").pack(pady=(0, 14))

    def show_analytics(self):
        if not self.students:
            messagebox.showinfo("No data", "Add student records to view analytics.")
            return
        win = tk.Toplevel(self)
        win.title("Analytics dashboard")
        win.geometry("820x600")
        win.configure(bg=BG)
        ttk.Label(win, text="Class analytics", style="Title.TLabel").pack(anchor="w", padx=20, pady=(16, 8))
        notebook = ttk.Notebook(win)
        notebook.pack(fill="both", expand=True, padx=20, pady=(0, 16))

        stats = core.subject_stats(self.students)
        tab1 = ttk.Frame(notebook)
        notebook.add(tab1, text="Subject averages")
        c1 = tk.Canvas(tab1, bg="white", highlightthickness=0)
        c1.pack(fill="both", expand=True, padx=8, pady=8)
        ttk.Label(tab1, text="Bars show the class average for each subject (0-100).",
                  style="Sub.TLabel").pack(pady=(0, 8))
        c1.bind("<Configure>", lambda _e: draw_bar_chart(
            c1, core.SUBJECTS, [stats[s]["average"] for s in core.SUBJECTS],
            100, range(0, 101, 20), "#4776e6"))

        dist = core.grade_distribution(self.students)
        top = max(max(dist.values()), 1)
        step = max(1, -(-top // 5))
        ymax = step * -(-top // step)
        tab2 = ttk.Frame(notebook)
        notebook.add(tab2, text="Grade distribution")
        c2 = tk.Canvas(tab2, bg="white", highlightthickness=0)
        c2.pack(fill="both", expand=True, padx=8, pady=8)
        ttk.Label(tab2, text="Number of students in each grade band.",
                  style="Sub.TLabel").pack(pady=(0, 8))
        c2.bind("<Configure>", lambda _e: draw_bar_chart(
            c2, core.GRADES, [dist[g] for g in core.GRADES], ymax, range(0, ymax + 1, step),
            "#4776e6", fmt="{:.0f}", bar_colors=[GRADE_COLORS[g] for g in core.GRADES]))

        tab3 = ttk.Frame(notebook, padding=14)
        notebook.add(tab3, text="Statistics")
        summary = core.class_summary(self.students)
        lines = [f"Students: {summary['count']}", f"Class average: {summary['average']:.2f}%",
                 f"Median average: {summary['median']:.2f}%",
                 f"Standard deviation: {summary['std_dev']:.2f}",
                 f"Highest / lowest average: {summary['highest']:.2f}% / {summary['lowest']:.2f}%",
                 f"Pass rate: {summary['pass_rate']:.1f}%",
                 f"Students needing attention: {summary['attention']}"]
        ttk.Label(tab3, text="   |   ".join(lines[:3]), style="Section.TLabel").pack(anchor="w")
        ttk.Label(tab3, text="   |   ".join(lines[3:]), style="Sub.TLabel").pack(anchor="w", pady=(4, 10))
        tree = ttk.Treeview(tab3, columns=("subject", "avg", "high", "low", "pass"),
                            show="headings", height=5)
        for col, label in [("subject", "SUBJECT"), ("avg", "CLASS AVG"), ("high", "HIGHEST"),
                           ("low", "LOWEST"), ("pass", f"PASS % (>= {core.SUBJECT_PASS_MARK:g})")]:
            tree.heading(col, text=label)
            tree.column(col, anchor="center", width=130)
        for subject in core.SUBJECTS:
            st = stats[subject]
            tree.insert("", "end", values=(subject, f"{st['average']:.1f}", f"{st['highest']:g}",
                                           f"{st['lowest']:g}", f"{st['pass_rate']:.0f}%"))
        tree.pack(fill="x")
        ttk.Label(tab3, text="Students needing attention (grade D/F or a failed subject):",
                  style="Section.TLabel").pack(anchor="w", pady=(16, 6))
        at_risk = [s for _, s in core.rank_students(self.students) if core.needs_attention(s)]
        text = "\n".join(
            f"\u2022 {s['name']} ({s['roll']}) - avg {s['average']:.1f}%, grade {s['grade']}"
            + (f", below pass mark in: {', '.join(core.failed_subjects(s))}" if core.failed_subjects(s) else "")
            for s in at_risk) or "None - the whole class is on track."
        ttk.Label(tab3, text=text, justify="left").pack(anchor="w")

    # ----- file operations -----
    def export_csv(self):
        if not self.students:
            messagebox.showinfo("Nothing to export", "There are no student records to export.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")],
                                            initialfile="campussolve_report.csv")
        if not path:
            return
        try:
            core.export_csv(path, self.students)
            messagebox.showinfo("Export complete", f"Report exported successfully:\n{path}")
        except OSError as exc:
            messagebox.showerror("Export failed", str(exc))

    def import_csv(self):
        path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not path:
            return
        records, errors = core.import_csv(path)
        fresh = [r for r in records if not core.roll_exists(self.students, r["roll"])]
        skipped = len(records) - len(fresh)
        if fresh and not self.commit(self.students + fresh, f"Imported {len(fresh)} student(s)."):
            return
        report = [f"Imported: {len(fresh)}", f"Skipped (roll already exists): {skipped}",
                  f"Rows with errors: {len(errors)}"]
        if errors:
            report += ["", "First problems found:"] + errors[:8]
            if len(errors) > 8:
                report.append(f"... and {len(errors) - 8} more.")
        messagebox.showinfo("Import finished", "\n".join(report))

    def backup_json(self):
        if not self.students:
            messagebox.showinfo("Nothing to back up", "There are no student records yet.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".json", initialfile="students_backup.json",
                                            filetypes=[("JSON files", "*.json")])
        if not path:
            return
        try:
            core.StudentStore(path).save(self.students)
            self.flash(f"Backup saved to {path}")
        except OSError as exc:
            messagebox.showerror("Backup failed", str(exc))

    def load_sample(self):
        if self.students and not messagebox.askyesno(
                "Load sample data", "Add the 12 demo students to your existing records?\n"
                "(Students with an existing roll number are skipped. You can undo this.)"):
            return
        fresh = [s for s in core.sample_students() if not core.roll_exists(self.students, s["roll"])]
        if not fresh:
            self.flash("Sample students are already loaded.")
            return
        self.commit(self.students + fresh, f"Loaded {len(fresh)} sample students.")

    # ----- help -----
    def show_grading_scale(self):
        lines = [f"Grade {g}: average of {t}% or more" for t, g in core.GRADE_SCALE[:-1]]
        lines.append("Grade F: average below 60%")
        lines += ["", f"A subject mark below {core.SUBJECT_PASS_MARK:g} counts as a failed subject.",
                  "Pass = any grade except F.",
                  "'Needs attention' = grade D or F, or at least one failed subject."]
        messagebox.showinfo("Grading scale", "\n".join(lines))

    def show_shortcuts(self):
        messagebox.showinfo("Keyboard shortcuts", "Ctrl+N  Add student\nCtrl+E  Edit selected\n"
                            "Delete  Delete selected\nCtrl+Z  Undo last change\nCtrl+F  Search\n"
                            "Esc     Clear search\nCtrl+R  Report card\nCtrl+D  Analytics\n"
                            "Ctrl+S  Export CSV")

    def show_about(self):
        messagebox.showinfo("About", f"{APP_NAME} v{__version__}\nStudent Performance Analyzer\n\n"
                            "Built with Python, Tkinter, JSON and CSV.\nNo third-party packages required.")


def run():
    CampusSolveApp().mainloop()
