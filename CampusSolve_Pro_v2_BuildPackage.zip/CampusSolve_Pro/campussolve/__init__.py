"""CampusSolve Pro - Student Performance Analyzer."""

__version__ = "2.0.0"
APP_NAME = "CampusSolve Pro"
