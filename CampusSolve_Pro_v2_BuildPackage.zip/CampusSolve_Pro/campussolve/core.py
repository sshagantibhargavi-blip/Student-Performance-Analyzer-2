"""Core logic for CampusSolve Pro.

Everything in this module is independent of Tkinter so that it can be
unit-tested, reused from the command line, and explained separately from the
user interface (separation of concerns).
"""
from __future__ import annotations

import csv
import json
import math
import os
import re
import shutil
import statistics
import sys
import tempfile
from collections import Counter
from datetime import datetime

# --------------------------------------------------------------------------
# Constants
# --------------------------------------------------------------------------
SUBJECTS = ["Python", "Mathematics", "Physics", "English", "Chemistry"]
MAX_MARK = 100.0
MAX_TOTAL = MAX_MARK * len(SUBJECTS)
SUBJECT_PASS_MARK = 40.0          # a subject mark below this is a failed subject
GRADE_SCALE = [(90, "A"), (80, "B"), (70, "C"), (60, "D"), (0, "F")]
GRADES = [g for _, g in GRADE_SCALE]
MAX_NAME_LENGTH = 60
ROLL_PATTERN = re.compile(r"^[\w\-/. ]{1,20}$")
MAX_IMPORT_ROWS = 5000
_CSV_DANGEROUS_START = ("=", "+", "-", "@")


class ValidationError(ValueError):
    """Raised when a student record is invalid."""


class DataFileError(Exception):
    """Raised when students.json cannot be safely loaded."""


# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
def app_dir() -> str:
    """Folder that holds students.json (next to the .exe when packaged)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def default_data_file() -> str:
    return os.path.join(app_dir(), "students.json")


# --------------------------------------------------------------------------
# Validation and record building
# --------------------------------------------------------------------------
def grade_for(average: float) -> str:
    for threshold, letter in GRADE_SCALE:
        if average >= threshold:
            return letter
    return "F"


def parse_mark(value, subject: str) -> float:
    """Convert user input to a mark in [0, 100] or raise ValidationError."""
    try:
        number = float(str(value).strip())
    except (TypeError, ValueError):
        raise ValidationError(f"{subject}: '{value}' is not a number.") from None
    if math.isnan(number) or math.isinf(number):
        raise ValidationError(f"{subject}: marks must be a finite number.")
    if not 0 <= number <= MAX_MARK:
        raise ValidationError(f"{subject}: marks must be between 0 and 100.")
    return round(number, 2)


def validate_identity(name, roll) -> tuple[str, str]:
    name = str(name or "").strip()
    roll = str(roll or "").strip()
    if not name:
        raise ValidationError("Student name is required.")
    if len(name) > MAX_NAME_LENGTH:
        raise ValidationError(f"Name must be at most {MAX_NAME_LENGTH} characters.")
    if not roll:
        raise ValidationError("Roll number is required.")
    if not ROLL_PATTERN.match(roll):
        raise ValidationError(
            "Roll number may contain letters, digits, space and - _ / . "
            "(maximum 20 characters).")
    return name, roll


def normalize_record(raw: dict) -> dict:
    """Validate raw data and (re)compute total, average and grade."""
    if not isinstance(raw, dict):
        raise ValidationError("A record must be an object.")
    name, roll = validate_identity(raw.get("name"), raw.get("roll"))
    marks = raw.get("marks")
    if not isinstance(marks, dict):
        raise ValidationError("A record is missing its marks.")
    clean = {}
    for subject in SUBJECTS:
        if subject not in marks:
            raise ValidationError(f"Marks for {subject} are missing.")
        clean[subject] = parse_mark(marks[subject], subject)
    total = round(sum(clean.values()), 2)
    average = round(total / len(SUBJECTS), 4)
    return {"name": name, "roll": roll, "marks": clean,
            "total": total, "average": average, "grade": grade_for(average)}


def roll_exists(students: list[dict], roll: str, exclude: dict | None = None) -> bool:
    key = roll.strip().casefold()
    return any(s["roll"].casefold() == key and s is not exclude for s in students)


# --------------------------------------------------------------------------
# Analytics
# --------------------------------------------------------------------------
def is_pass(student: dict) -> bool:
    return student["grade"] != "F"


def failed_subjects(student: dict) -> list[str]:
    return [s for s in SUBJECTS if student["marks"][s] < SUBJECT_PASS_MARK]


def needs_attention(student: dict) -> bool:
    """Grade D/F or at least one failed subject."""
    return student["grade"] in ("D", "F") or bool(failed_subjects(student))


def rank_students(students: list[dict]) -> list[tuple[int, dict]]:
    """Competition ranking (1,2,2,4): equal averages share a rank."""
    ordered = sorted(students, key=lambda s: (-round(s["average"], 2), s["name"].casefold()))
    result, previous_avg, previous_rank = [], None, 0
    for position, student in enumerate(ordered, 1):
        avg = round(student["average"], 2)
        rank = previous_rank if avg == previous_avg else position
        result.append((rank, student))
        previous_avg, previous_rank = avg, rank
    return result


def grade_distribution(students: list[dict]) -> dict[str, int]:
    counts = Counter(s["grade"] for s in students)
    return {g: counts.get(g, 0) for g in GRADES}


def class_summary(students: list[dict]) -> dict:
    n = len(students)
    if n == 0:
        return {"count": 0, "average": 0.0, "median": 0.0, "std_dev": 0.0,
                "highest": 0.0, "lowest": 0.0, "pass_rate": 0.0,
                "topper": None, "attention": 0}
    averages = [s["average"] for s in students]
    ranked = rank_students(students)
    return {
        "count": n,
        "average": statistics.fmean(averages),
        "median": statistics.median(averages),
        "std_dev": statistics.pstdev(averages),
        "highest": max(averages),
        "lowest": min(averages),
        "pass_rate": 100.0 * sum(is_pass(s) for s in students) / n,
        "topper": ranked[0][1]["name"],
        "attention": sum(needs_attention(s) for s in students),
    }


def subject_stats(students: list[dict]) -> dict[str, dict]:
    stats = {}
    for subject in SUBJECTS:
        values = [s["marks"][subject] for s in students]
        if values:
            stats[subject] = {
                "average": statistics.fmean(values), "highest": max(values),
                "lowest": min(values),
                "pass_rate": 100.0 * sum(v >= SUBJECT_PASS_MARK for v in values) / len(values)}
        else:
            stats[subject] = {"average": 0.0, "highest": 0.0, "lowest": 0.0, "pass_rate": 0.0}
    return stats


def student_insights(student: dict, students: list[dict]) -> dict:
    marks = student["marks"]
    best = max(SUBJECTS, key=lambda s: marks[s])
    weakest = min(SUBJECTS, key=lambda s: marks[s])
    ranking = {id(s): r for r, s in rank_students(students)}
    stats = subject_stats(students)
    remarks = {"A": "Outstanding performance - keep it up.",
               "B": "Very good performance with room to reach the top band.",
               "C": "Satisfactory performance; focused revision can lift the grade.",
               "D": "Below expectations; regular practice and mentoring are advised.",
               "F": "Unsatisfactory; immediate academic support is recommended."}
    return {
        "rank": ranking.get(id(student)), "total_students": len(students),
        "best_subject": best, "weakest_subject": weakest,
        "vs_class": {s: round(marks[s] - stats[s]["average"], 2) for s in SUBJECTS},
        "failed_subjects": failed_subjects(student),
        "remark": remarks[student["grade"]],
    }


def report_card_text(student: dict, students: list[dict]) -> str:
    info = student_insights(student, students)
    lines = ["CAMPUSSOLVE PRO - STUDENT REPORT CARD", "=" * 46,
             f"Name        : {student['name']}", f"Roll number : {student['roll']}",
             f"Rank        : {info['rank']} of {info['total_students']}", "",
             f"{'Subject':<14}{'Marks':>8}{'vs class':>12}", "-" * 34]
    for subject in SUBJECTS:
        diff = info["vs_class"][subject]
        lines.append(f"{subject:<14}{student['marks'][subject]:>8.1f}{diff:>+12.1f}")
    lines += ["-" * 34,
              f"Total       : {student['total']:.1f} / {MAX_TOTAL:.0f}",
              f"Average     : {student['average']:.2f}%", f"Grade       : {student['grade']}", "",
              f"Strongest subject : {info['best_subject']}",
              f"Needs focus       : {info['weakest_subject']}"]
    if info["failed_subjects"]:
        lines.append("Below pass mark   : " + ", ".join(info["failed_subjects"]))
    lines += ["", "Remark: " + info["remark"], "",
              f"Generated {datetime.now():%d %b %Y, %H:%M}"]
    return "\n".join(lines)


# --------------------------------------------------------------------------
# Storage (JSON, atomic writes, automatic .bak copy)
# --------------------------------------------------------------------------
class StudentStore:
    def __init__(self, path: str | None = None):
        self.path = path or default_data_file()

    def load(self) -> list[dict]:
        if not os.path.exists(self.path):
            return []
        try:
            with open(self.path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            if not isinstance(data, list):
                raise ValidationError("The JSON root must be a list of students.")
            records = [normalize_record(item) for item in data]
        except (OSError, json.JSONDecodeError, ValidationError) as exc:
            raise DataFileError(str(exc)) from exc
        seen = set()
        for record in records:
            key = record["roll"].casefold()
            if key in seen:
                raise DataFileError(f"Duplicate roll number found: {record['roll']}")
            seen.add(key)
        return records

    def quarantine(self) -> str | None:
        """Copy an unreadable data file aside so a later save cannot destroy it."""
        if not os.path.exists(self.path):
            return None
        target = f"{self.path}.corrupt-{datetime.now():%Y%m%d-%H%M%S}"
        try:
            shutil.copy2(self.path, target)
            return target
        except OSError:
            return None

    def save(self, students: list[dict]) -> None:
        folder = os.path.dirname(self.path) or "."
        if os.path.exists(self.path):
            try:
                shutil.copy2(self.path, self.path + ".bak")
            except OSError:
                pass
        fd, temp_path = tempfile.mkstemp(prefix="students_", suffix=".tmp", dir=folder, text=True)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(students, handle, indent=4, ensure_ascii=False)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_path, self.path)
        except Exception:
            try:
                os.remove(temp_path)
            except OSError:
                pass
            raise


# --------------------------------------------------------------------------
# CSV import / export
# --------------------------------------------------------------------------
def _safe_cell(value: str) -> str:
    """Neutralise spreadsheet formula injection (=, +, -, @ prefixes)."""
    return "'" + value if value.startswith(_CSV_DANGEROUS_START) else value


def _unsafe_cell(value: str) -> str:
    if value.startswith("'") and value[1:].startswith(_CSV_DANGEROUS_START):
        return value[1:]
    return value


def export_csv(path: str, students: list[dict]) -> None:
    with open(path, "w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle)
        writer.writerow(["Rank", "Name", "Roll Number"] + SUBJECTS +
                        ["Total", "Average (%)", "Grade"])
        for rank, s in rank_students(students):
            writer.writerow([rank, _safe_cell(s["name"]), _safe_cell(s["roll"])] +
                            [s["marks"][sub] for sub in SUBJECTS] +
                            [s["total"], round(s["average"], 2), s["grade"]])


def _header_key(text: str) -> str:
    return re.sub(r"[^a-z]", "", (text or "").lower())


def import_csv(path: str) -> tuple[list[dict], list[str]]:
    """Return (valid_records, error_messages). Never raises for bad rows."""
    records, errors, seen = [], [], set()
    try:
        with open(path, "r", newline="", encoding="utf-8-sig") as handle:
            reader = csv.reader(handle)
            header = next(reader, None)
            if not header:
                return [], ["The file is empty."]
            index = {_header_key(h): i for i, h in enumerate(header)}
            name_col = next((index[k] for k in ("name", "studentname") if k in index), None)
            roll_col = next((index[k] for k in ("roll", "rollnumber", "rollno") if k in index), None)
            subject_cols = {s: index.get(_header_key(s)) for s in SUBJECTS}
            required = [("Name", name_col), ("Roll Number", roll_col)] + list(subject_cols.items())
            missing = [label for label, col in required if col is None]
            if missing:
                return [], ["Missing required column(s): " + ", ".join(missing)]

            def cell(row, col):
                return row[col] if col < len(row) else ""

            for line_no, row in enumerate(reader, 2):
                if line_no - 1 > MAX_IMPORT_ROWS:
                    errors.append(f"Stopped after {MAX_IMPORT_ROWS} rows.")
                    break
                if not any(c.strip() for c in row):
                    continue
                try:
                    record = normalize_record({
                        "name": _unsafe_cell(cell(row, name_col).strip()),
                        "roll": _unsafe_cell(cell(row, roll_col).strip()),
                        "marks": {s: cell(row, c) for s, c in subject_cols.items()}})
                    key = record["roll"].casefold()
                    if key in seen:
                        raise ValidationError(f"duplicate roll number '{record['roll']}' in file.")
                    seen.add(key)
                    records.append(record)
                except ValidationError as exc:
                    errors.append(f"Row {line_no}: {exc}")
    except (OSError, UnicodeDecodeError, csv.Error) as exc:
        return [], [f"Could not read the file: {exc}"]
    return records, errors


# --------------------------------------------------------------------------
# Sample data (for demonstrations)
# --------------------------------------------------------------------------
_SAMPLE = [
    ("Aarav Sharma", "CS101", (96, 92, 88, 90, 94)),
    ("Ananya Reddy", "CS102", (91, 95, 89, 93, 90)),
    ("Rohan Kumar", "CS103", (84, 78, 80, 75, 82)),
    ("Priya Nair", "CS104", (88, 85, 79, 91, 84)),
    ("Karthik Rao", "CS105", (72, 68, 74, 70, 65)),
    ("Sneha Patel", "CS106", (65, 62, 58, 70, 61)),
    ("Vikram Singh", "CS107", (55, 48, 52, 60, 45)),
    ("Meera Iyer", "CS108", (78, 82, 76, 85, 80)),
    ("Arjun Das", "CS109", (45, 38, 42, 50, 35)),
    ("Divya Menon", "CS110", (93, 89, 94, 96, 91)),
    ("Imran Khan", "CS111", (69, 71, 66, 73, 68)),
    ("Lakshmi Devi", "CS112", (82, 76, 85, 79, 88)),
]


def sample_students() -> list[dict]:
    return [normalize_record({"name": n, "roll": r, "marks": dict(zip(SUBJECTS, m))})
            for n, r, m in _SAMPLE]
