"""Generate the CampusSolve Pro project report (PDF).

    python docs/build_report.py --name "Your Name" --roll "Your Roll" \
        --course "B.Tech CSE" --institution "Your College" --guide "Prof. Name"

Needs:  pip install reportlab matplotlib
Charts and test results in the report are produced from the real code, not typed by hand.
"""
from __future__ import annotations

import argparse
import io
import os
import sys
import tempfile
import unittest
from datetime import date

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.ticker  # noqa: E402
from matplotlib.patches import FancyBboxPatch  # noqa: E402
from reportlab.lib import colors  # noqa: E402
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY  # noqa: E402
from reportlab.lib.pagesizes import A4  # noqa: E402
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet  # noqa: E402
from reportlab.lib.units import cm  # noqa: E402
from reportlab.platypus import (BaseDocTemplate, Frame, Image, PageBreak, PageTemplate,  # noqa: E402
                                Paragraph, Preformatted, Spacer, Table, TableStyle, KeepTogether)
from reportlab.platypus.tableofcontents import TableOfContents  # noqa: E402

from campussolve import APP_NAME, __version__, core  # noqa: E402

NAVY, BLUE, LIGHT = colors.HexColor("#14213d"), colors.HexColor("#315efb"), colors.HexColor("#eef2fb")


# ------------------------------------------------------------------ evidence
def run_tests():
    """Run the real unit tests and return (total, failures, per_class dict)."""
    suite = unittest.defaultTestLoader.discover(os.path.join(ROOT, "tests"))
    per_class = {}

    def walk(item):
        if isinstance(item, unittest.TestSuite):
            for sub in item:
                walk(sub)
        else:
            per_class[type(item).__name__] = per_class.get(type(item).__name__, 0) + 1
    walk(suite)                       # count BEFORE running: unittest empties the suite afterwards
    result = unittest.TextTestRunner(stream=io.StringIO(), verbosity=0).run(suite)
    return result.testsRun, len(result.failures) + len(result.errors), per_class


def make_figures(folder):
    students = core.sample_students()
    stats = core.subject_stats(students)
    dist = core.grade_distribution(students)
    paths = {}

    fig, ax = plt.subplots(figsize=(6.4, 3.2), dpi=200)
    bars = ax.bar(core.SUBJECTS, [stats[s]["average"] for s in core.SUBJECTS], color="#4776e6")
    ax.bar_label(bars, fmt="%.1f", fontsize=8)
    ax.set_ylim(0, 100); ax.set_ylabel("Class average (marks)")
    ax.set_title("Subject-wise class average (12 sample students)", fontsize=10)
    ax.spines[["top", "right"]].set_visible(False)
    paths["subjects"] = os.path.join(folder, "subjects.png"); fig.tight_layout(); fig.savefig(paths["subjects"]); plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.4, 3.0), dpi=200)
    palette = ["#067647", "#1d4ed8", "#475569", "#b45309", "#b42318"]
    bars = ax.bar(list(dist), list(dist.values()), color=palette)
    ax.bar_label(bars, fontsize=8)
    ax.set_ylabel("Students"); ax.set_title("Grade distribution", fontsize=10)
    ax.yaxis.set_major_locator(matplotlib.ticker.MaxNLocator(integer=True))
    ax.spines[["top", "right"]].set_visible(False)
    paths["grades"] = os.path.join(folder, "grades.png"); fig.tight_layout(); fig.savefig(paths["grades"]); plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.2, 3.6), dpi=200)
    ax.set_xlim(0, 10); ax.set_ylim(0, 5); ax.axis("off")

    def box(x, y, w, h, text, fc):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05", fc=fc, ec="#14213d", lw=1))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=8, color="#14213d")
    box(0.2, 3.7, 9.6, 1.0, "Presentation layer  -  campussolve/gui.py  (Tkinter: windows, dialogs, charts, menus)", "#dbe5ff")
    box(0.2, 2.0, 9.6, 1.3, "Business-logic layer  -  campussolve/core.py\nvalidation  |  grading  |  ranking  |  statistics  |  report cards  |  CSV import/export", "#e7f5ec")
    box(0.2, 0.3, 4.5, 1.2, "Storage\nstudents.json (atomic write + .bak)", "#fff3d6")
    box(5.3, 0.3, 4.5, 1.2, "Files\nCSV reports, JSON backups, TXT report cards", "#fff3d6")
    for x in (2.5, 7.5):
        ax.annotate("", xy=(x, 3.3), xytext=(x, 3.7), arrowprops=dict(arrowstyle="<->", color="#14213d"))
        ax.annotate("", xy=(x, 1.5), xytext=(x, 2.0), arrowprops=dict(arrowstyle="<->", color="#14213d"))
    paths["arch"] = os.path.join(folder, "arch.png"); fig.tight_layout(); fig.savefig(paths["arch"]); plt.close(fig)
    return paths, students, stats


# ------------------------------------------------------------------ document
class Report(BaseDocTemplate):
    def __init__(self, filename, meta, **kw):
        super().__init__(filename, pagesize=A4, leftMargin=2.2 * cm, rightMargin=2.2 * cm,
                         topMargin=2.2 * cm, bottomMargin=2.2 * cm,
                         title=f"{APP_NAME} - Project Report", author=meta["name"], **kw)
        self.meta = meta
        frame = Frame(self.leftMargin, self.bottomMargin, self.width, self.height, id="f")
        self.addPageTemplates([PageTemplate(id="cover", frames=[frame], onPage=lambda c, d: None),
                               PageTemplate(id="body", frames=[frame], onPage=self.decorate)])

    def decorate(self, canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 8); canvas.setFillColor(colors.HexColor("#64748b"))
        canvas.drawString(2.2 * cm, 1.3 * cm, f"{APP_NAME} v{__version__} - Project Report")
        canvas.drawRightString(A4[0] - 2.2 * cm, 1.3 * cm, f"Page {doc.page}")
        canvas.setStrokeColor(colors.HexColor("#d6deeb")); canvas.line(2.2 * cm, 1.7 * cm, A4[0] - 2.2 * cm, 1.7 * cm)
        canvas.restoreState()

    def afterFlowable(self, flowable):
        if isinstance(flowable, Paragraph) and flowable.style.name in ("H1", "H2"):
            level = 0 if flowable.style.name == "H1" else 1
            text = flowable.getPlainText()
            key = f"h{self.seq.nextf('toc')}"
            self.canv.bookmarkPage(key)
            self.notify("TOCEntry", (level, text, self.page, key))


def build(path, meta):
    total, failed, per_class = run_tests()
    tmp = tempfile.mkdtemp()
    figs, students, stats = make_figures(tmp)
    summary = core.class_summary(students)

    ss = getSampleStyleSheet()
    body = ParagraphStyle("Body", parent=ss["BodyText"], fontName="Helvetica", fontSize=10, leading=14.5,
                          alignment=TA_JUSTIFY, spaceAfter=7)
    h1 = ParagraphStyle("H1", parent=ss["Heading1"], fontName="Helvetica-Bold", fontSize=16, textColor=NAVY,
                        spaceBefore=6, spaceAfter=10, keepWithNext=1)
    h2 = ParagraphStyle("H2", parent=ss["Heading2"], fontName="Helvetica-Bold", fontSize=12, textColor=BLUE,
                        spaceBefore=10, spaceAfter=5, keepWithNext=1)
    cap = ParagraphStyle("Cap", parent=body, fontSize=8.5, textColor=colors.HexColor("#64748b"),
                         alignment=TA_CENTER, spaceAfter=10)
    cell = ParagraphStyle("Cell", parent=body, fontSize=8.5, leading=11, alignment=0, spaceAfter=0)
    cellb = ParagraphStyle("CellB", parent=cell, fontName="Helvetica-Bold", textColor=colors.white)
    code = ParagraphStyle("Code", fontName="Courier", fontSize=7.8, leading=10, backColor=LIGHT,
                          borderPadding=6, spaceAfter=10, leftIndent=4)
    bullet = ParagraphStyle("Bul", parent=body, leftIndent=14, bulletIndent=2, spaceAfter=3, alignment=0)

    def P(t): return Paragraph(t, body)
    def B(items): return [Paragraph(i, bullet, bulletText="\u2022") for i in items]

    def table(rows, widths, header=True, zebra=True):
        data = [[Paragraph(str(c), cellb if (header and r == 0) else cell) for c in row] for r, row in enumerate(rows)]
        t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
        style = [("VALIGN", (0, 0), (-1, -1), "TOP"), ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd5e1")),
                 ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]
        if header:
            style.append(("BACKGROUND", (0, 0), (-1, 0), NAVY))
        if zebra:
            style += [("BACKGROUND", (0, r), (-1, r), LIGHT) for r in range(2 if header else 1, len(rows), 2)]
        t.setStyle(TableStyle(style))
        return t

    W = A4[0] - 4.4 * cm
    s = []

    # ---- cover
    s += [Spacer(1, 3.2 * cm),
          Paragraph("PROJECT REPORT", ParagraphStyle("c0", parent=body, fontSize=11, alignment=TA_CENTER, textColor=BLUE)),
          Spacer(1, 0.4 * cm),
          Paragraph(APP_NAME, ParagraphStyle("c1", parent=body, fontName="Helvetica-Bold", fontSize=34, leading=40,
                                             alignment=TA_CENTER, textColor=NAVY)),
          Paragraph("Student Performance Analyzer", ParagraphStyle("c2", parent=body, fontSize=16, alignment=TA_CENTER,
                                                                  textColor=colors.HexColor("#475569"))),
          Spacer(1, 0.6 * cm),
          Paragraph("A desktop application for managing student marks, ranking and academic analytics, "
                    "built with Python, Tkinter, JSON and CSV.",
                    ParagraphStyle("c3", parent=body, alignment=TA_CENTER, fontSize=10.5)),
          Spacer(1, 3.2 * cm)]
    ident = [["Submitted by", meta["name"]], ["Roll / Registration no.", meta["roll"]],
             ["Programme", meta["course"]], ["Institution", meta["institution"]],
             ["Project guide", meta["guide"]], ["Version / Date", f"v{__version__}  |  {date.today():%d %B %Y}"]]
    t = Table([[Paragraph(f"<b>{a}</b>", cell), Paragraph(b, cell)] for a, b in ident], colWidths=[5.2 * cm, 8.8 * cm], hAlign="CENTER")
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd5e1")), ("BACKGROUND", (0, 0), (0, -1), LIGHT),
                           ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
    s += [t, PageBreak()]
    from reportlab.platypus import NextPageTemplate
    s.insert(0, NextPageTemplate("body"))

    # ---- declaration, abstract, TOC
    s += [Paragraph("Declaration", h1),
          P(f"I, <b>{meta['name']}</b>, declare that this report and the accompanying software "
            f"<i>{APP_NAME}</i> are my own work, prepared for the programme <b>{meta['course']}</b> at "
            f"<b>{meta['institution']}</b> under the guidance of <b>{meta['guide']}</b>. Standard-library "
            "documentation and the references listed at the end were consulted; all code was written, "
            "tested and understood by me."),
          Spacer(1, 0.8 * cm), P(f"Signature: ______________________ &nbsp;&nbsp;&nbsp; Date: {date.today():%d %B %Y}"),
          Spacer(1, 0.6 * cm),
          Paragraph("Abstract", h1),
          P("Manual preparation of student marksheets is slow and error-prone: totals are recalculated by hand, "
            "ranks are not updated when a mark changes, and weak subjects are noticed late. CampusSolve Pro "
            "is a lightweight desktop application that stores student records locally, validates every "
            "entry, automatically computes totals, averages, grades and ranks, and presents class-level "
            "analytics (subject averages, grade distribution, pass rate, median, standard deviation, and a "
            "list of students needing attention)."),
          P(f"Version 2.0 separates the business logic from the user interface, adds {total} automated unit tests, "
            "an undo facility, CSV import, per-student report cards, and several data-safety features "
            "(atomic saves, automatic backups, corrupt-file quarantine). The application needs only the Python "
            "standard library and can be packaged as a stand-alone Windows executable."),
          P("<b>Keywords:</b> student performance analysis, Python, Tkinter, JSON, data validation, ranking, unit testing."),
          PageBreak(), Paragraph("Table of Contents", h1)]
    toc = TableOfContents()
    toc.levelStyles = [ParagraphStyle("t0", fontName="Helvetica-Bold", fontSize=10, leading=15, leftIndent=0),
                       ParagraphStyle("t1", fontName="Helvetica", fontSize=9, leading=12, leftIndent=16)]
    s += [toc, PageBreak()]

    # ---- 1 Introduction
    s += [Paragraph("1. Introduction", h1), Paragraph("1.1 Background", h2),
          P("Colleges routinely record marks in spreadsheets or on paper. Spreadsheets lack input validation, "
            "do not guard against duplicate roll numbers, and silently produce wrong results when a formula "
            "is overwritten. A small purpose-built tool removes these risks and lets staff focus on "
            "interpreting results instead of computing them."),
          Paragraph("1.2 Problem statement", h2),
          P("Design and implement an offline, easy-to-install application that lets an instructor record "
            "five subject marks per student, guarantees data correctness, and immediately shows each "
            "student's total, average, grade and rank together with class-level insights."),
          Paragraph("1.3 Objectives", h2)]
    s += B(["Provide create, read, update and delete operations with strict validation.",
            "Compute total, average, grade and rank automatically and consistently.",
            "Offer analytics that highlight strong and weak subjects and students needing support.",
            "Guarantee that data is never silently lost or corrupted.",
            "Keep the code modular and testable, with no third-party runtime dependencies.",
            "Allow data exchange through CSV and JSON."])
    s += [Paragraph("1.4 Scope and limitations", h2),
          P("The system is a single-user, offline desktop tool for one class at a time with five fixed "
            "subjects. Multi-user access, authentication and database back-ends are outside the present "
            "scope and are listed under future work (Section 9).")]

    # ---- 2 Requirements
    s += [Paragraph("2. Requirement Analysis", h1), Paragraph("2.1 Functional requirements", h2),
          table([["ID", "Requirement", "Module"],
                 ["FR1", "Add a student with name, unique roll number and five marks (0-100).", "gui / core.validate"],
                 ["FR2", "Edit and delete records; deletion needs confirmation and can be undone.", "gui"],
                 ["FR3", "Compute total, average, grade; rank students (ties share a rank).", "core.rank_students"],
                 ["FR4", "Search by name or roll; filter by grade or 'needs attention'; sort by any column.", "gui"],
                 ["FR5", "Dashboard: count, class average, topper, pass rate, students needing attention.", "core.class_summary"],
                 ["FR6", "Analytics: subject averages, grade distribution, median, standard deviation.", "core / gui"],
                 ["FR7", "Per-student report card with strengths, weaknesses and a remark.", "core.report_card_text"],
                 ["FR8", "Import students from CSV with a row-by-row error report; export ranked CSV; JSON backup.", "core.import_csv / export_csv"],
                 ["FR9", "Persist data between sessions in students.json.", "core.StudentStore"]],
                [1.2 * cm, 11 * cm, W - 12.2 * cm]),
          Paragraph("2.2 Non-functional requirements", h2)]
    s += B(["<b>Reliability:</b> atomic writes, automatic .bak copy, corrupt-file quarantine, rollback when saving fails.",
            "<b>Usability:</b> keyboard shortcuts, live grade preview while typing, clear error messages.",
            "<b>Portability:</b> pure standard-library Python 3.10+; runs on Windows, macOS and Linux.",
            "<b>Maintainability:</b> logic separated from the UI; automated tests; type hints and docstrings.",
            "<b>Security:</b> input validation, rejection of NaN/infinity marks, CSV formula-injection protection."])
    s += [Paragraph("2.3 Hardware and software", h2),
          table([["Item", "Minimum"], ["Processor / RAM", "Any dual-core CPU, 2 GB RAM"], ["Operating system", "Windows 10/11, macOS 12+, Ubuntu 22.04+"],
                 ["Software", "Python 3.10+ with Tkinter (included in the python.org installer)"],
                 ["Optional", "PyInstaller (build .exe), reportlab + matplotlib (regenerate this report)"]],
                [4.5 * cm, W - 4.5 * cm])]

    # ---- 3 Design
    s += [Paragraph("3. System Design", h1), Paragraph("3.1 Architecture", h2),
          P("The application follows a layered design. The presentation layer only displays data and "
            "forwards user actions; every rule (validation, grading, ranking, statistics, file handling) lives "
            "in <font face='Courier'>core.py</font>. This separation allowed the logic to be verified with "
            "automated tests independent of the GUI."),
          Image(figs["arch"], width=W, height=W * 0.5),
          Paragraph("Figure 1: Layered architecture of CampusSolve Pro", cap),
          KeepTogether([Paragraph("3.2 Data model", h2),
          P("Each student is one JSON object. Derived fields (total, average, grade) are always "
            "<i>recomputed</i> on load, so a hand-edited or old file can never display stale results."),
          Preformatted('{\n  "name": "Aarav Sharma",   "roll": "CS101",\n  "marks": {"Python": 96.0, "Mathematics": 92.0, "Physics": 88.0,\n            "English": 90.0, "Chemistry": 94.0},\n  "total": 460.0,  "average": 92.0,  "grade": "A"\n}', code)]),
          Paragraph("3.3 Module overview", h2),
          table([["File", "Responsibility"],
                 ["main.py", "Entry point; <font face='Courier'>--summary</font> prints a terminal report without a GUI."],
                 ["campussolve/core.py", "Validation, grading, ranking, statistics, report cards, storage, CSV, sample data."],
                 ["campussolve/gui.py", "Main window, dialogs, charts drawn on Canvas, menus, shortcuts, undo stack."],
                 ["tests/test_core.py", f"{total} unit tests for the logic layer."],
                 ["docs/build_report.py", "Generates this report from the real code and test results."]],
                [4.6 * cm, W - 4.6 * cm])]

    # ---- 4 Implementation
    s += [Paragraph("4. Implementation", h1), Paragraph("4.1 Technologies", h2),
          P("Python 3 (standard library only): <b>tkinter/ttk</b> for the interface, <b>json</b> for storage, "
            "<b>csv</b> for exchange, <b>statistics</b> for mean, median and standard deviation, "
            "<b>tempfile/os.replace</b> for atomic saving, and <b>unittest</b> for testing."),
          Paragraph("4.2 Key algorithms", h2),
          P("<b>Grading.</b> The grade is chosen by scanning the scale from the highest threshold downwards."),
          Preformatted('GRADE_SCALE = [(90,"A"), (80,"B"), (70,"C"), (60,"D"), (0,"F")]\n\ndef grade_for(average):\n    for threshold, letter in GRADE_SCALE:\n        if average >= threshold:\n            return letter', code),
          P("<b>Ranking with ties.</b> Students are sorted by rounded average (descending). A student receives the "
            "previous student's rank when the averages are equal, otherwise their position, giving 1, 2, 2, 4."),
          Preformatted('for position, student in enumerate(ordered, 1):\n    avg = round(student["average"], 2)\n    rank = previous_rank if avg == previous_avg else position', code),
          P("<b>Atomic saving.</b> Data is written to a temporary file in the same folder, flushed and "
            "fsync-ed, then moved over the real file with <font face='Courier'>os.replace</font>. A crash during "
            "saving therefore leaves either the complete old file or the complete new file, never a half-written one. "
            "The previous version is also kept as <font face='Courier'>students.json.bak</font>."),
          P("<b>Undo.</b> Records are never modified in place; every change builds a new list. The previous "
            "list is pushed on a bounded stack (20 entries), so undo is a constant-time swap followed by a save."),
          Paragraph("4.3 Validation rules", h2),
          table([["Field", "Rule"],
                 ["Name", "Required; at most 60 characters."],
                 ["Roll number", "Required; 1-20 characters (letters, digits, space, - _ / .); unique, case-insensitive."],
                 ["Marks", "Numeric, finite (NaN and infinity rejected), 0 to 100 inclusive, stored to 2 decimals."],
                 ["CSV import", "Required columns checked; every invalid row reported with its line number; duplicates skipped."],
                 ["CSV export", "Cells starting with = + - @ are prefixed with an apostrophe to prevent formula injection in Excel."]],
                [3.2 * cm, W - 3.2 * cm])]

    # ---- 5 UI
    s += [Paragraph("5. User Interface", h1),
          P("The main window contains five dashboard cards, a toolbar, a search box with a grade filter, and a "
            "sortable table whose rows are coloured by grade. Double-clicking a row opens the edit dialog, "
            "which shows a live preview of total, average and grade while marks are typed."),
          table([["Screen", "Purpose"],
                 ["Main window", "Dashboard cards, searchable/sortable/filterable table, status bar."],
                 ["Add / Edit dialog", "Validated form with live preview; Enter saves, Esc cancels."],
                 ["Report card", "Rank, marks versus class average, strongest and weakest subject, remark; saved as text."],
                 ["Rankings", "Leaderboard with shared ranks for ties."],
                 ["Analytics", "Tab 1 subject-average chart; Tab 2 grade distribution; Tab 3 statistics and the list of students needing attention."],
                 ["Menus", "File (import/export/backup/sample data), Edit (undo), View, Help (grading scale, shortcuts, about)."]],
                [3.6 * cm, W - 3.6 * cm]),
          Spacer(1, 6),
          P("Keyboard shortcuts: <b>Ctrl+N</b> add, <b>Ctrl+E</b> edit, <b>Del</b> delete, <b>Ctrl+Z</b> undo, "
            "<b>Ctrl+F</b> search, <b>Ctrl+R</b> report card, <b>Ctrl+D</b> analytics, <b>Ctrl+S</b> export.")]

    # ---- 6 Testing
    manual = [["M1", "Add student with marks 120", "Rejected: 'marks must be between 0 and 100'"],
              ["M2", "Add a roll number that already exists (different case)", "Rejected as duplicate"],
              ["M3", "Edit marks so the average crosses 90", "Grade changes B to A; rank updates"],
              ["M4", "Delete a student, press Ctrl+Z", "Student restored and saved"],
              ["M5", "Close and reopen the application", "All records still present"],
              ["M6", "Import CSV with one bad row", "Good rows imported; error line reported"],
              ["M7", "Corrupt students.json by hand", "Warning shown; copy of bad file kept; app starts empty"]]
    s += [Paragraph("6. Testing", h1), Paragraph("6.1 Automated unit tests", h2),
          P(f"The suite contains <b>{total}</b> tests; at the time this report was generated "
            f"<b>{total - failed} passed and {failed} failed</b>. Run them with "
            "<font face='Courier'>python -m unittest discover -s tests -v</font>."),
          table([["Test group", "Tests", "What is checked"]] +
                [[k, str(v), d] for k, v, d in [
                    ("GradeTests", per_class.get("GradeTests", 0), "Every grade boundary (89.99 vs 90, 59.99 vs 60, ...)"),
                    ("ValidationTests", per_class.get("ValidationTests", 0), "Out-of-range, non-numeric, NaN/inf, boundary marks, identity rules, duplicate rolls"),
                    ("AnalyticsTests", per_class.get("AnalyticsTests", 0), "Tied ranks, empty class, mean/median/std-dev, subject stats, attention rule, report card"),
                    ("StorageTests", per_class.get("StorageTests", 0), "Round-trip, no temp files left, .bak backup, corrupt JSON, duplicates, legacy files"),
                    ("CsvTests", per_class.get("CsvTests", 0), "Round-trip, formula injection, bad rows, missing columns, missing file"),
                    ("SampleDataTests", per_class.get("SampleDataTests", 0), "Demo data is valid and diverse")]],
                [3.6 * cm, 1.4 * cm, W - 5 * cm]),
          Paragraph("6.2 Manual test cases (GUI)", h2),
          table([["ID", "Action", "Expected result"]] + manual, [1.1 * cm, 7.4 * cm, W - 8.5 * cm]),
          P("<i>The manual cases are the scripted demonstration steps; record the actual outcome and "
            "screenshots on your machine in Appendix B.</i>")]

    # ---- 7 Results
    top5 = core.rank_students(students)[:5]
    s += [Paragraph("7. Results and Analysis", h1),
          P(f"To illustrate the analytics, the built-in synthetic sample of <b>{summary['count']}</b> students was analysed "
            "(<i>File &gt; Load sample data</i>). These figures are produced by the same functions the application uses."),
          table([["Measure", "Value"],
                 ["Class average", f"{summary['average']:.2f}%"], ["Median average", f"{summary['median']:.2f}%"],
                 ["Standard deviation", f"{summary['std_dev']:.2f}"], ["Pass rate", f"{summary['pass_rate']:.1f}%"],
                 ["Students needing attention", str(summary['attention'])], ["Topper", summary['topper']]],
                [6 * cm, W - 6 * cm]), Spacer(1, 8),
          KeepTogether([Image(figs["subjects"], width=W * 0.9, height=W * 0.9 * 0.5),
                        Paragraph("Figure 2: Subject-wise class average (generated by core.subject_stats)", cap)]),
          KeepTogether([Image(figs["grades"], width=W * 0.9, height=W * 0.9 * 0.47),
                        Paragraph("Figure 3: Grade distribution (generated by core.grade_distribution)", cap)]),
          Paragraph("Top five students", h2),
          table([["Rank", "Roll", "Name", "Average %", "Grade"]] +
                [[str(r), x["roll"], x["name"], f"{x['average']:.2f}", x["grade"]] for r, x in top5],
                [1.5 * cm, 2.5 * cm, W - 9.5 * cm, 3 * cm, 2.5 * cm])]
    weakest = min(core.SUBJECTS, key=lambda k: stats[k]["average"])
    strongest = max(core.SUBJECTS, key=lambda k: stats[k]["average"])
    s += [P(f"<b>Interpretation.</b> On this sample, <b>{strongest}</b> has the highest class average "
            f"({stats[strongest]['average']:.1f}) and <b>{weakest}</b> the lowest ({stats[weakest]['average']:.1f}); "
            "an instructor would target extra support at the weakest subject and at the students on the "
            "attention list.")]

    # ---- 8 Enhancements
    s += [Paragraph("8. Enhancements over Version 1", h1),
          table([["Area", "Version 1", "Version 2"],
                 ["Structure", "One 302-line file", "Logic (core), UI (gui), entry point, tests, docs"],
                 ["Testing", "None", f"{total} automated tests"],
                 ["Ranking", "Sorted order only", "Competition ranking with ties"],
                 ["Safety", "Atomic save", "+ .bak copy, quarantine of corrupt files, rollback on save failure, undo"],
                 ["Table", "Search", "+ sorting, grade filter, attention filter, colour-coded grades"],
                 ["Analytics", "Subject bar chart", "+ grade distribution, median, std-dev, per-subject pass rate, attention list"],
                 ["Data exchange", "CSV export", "+ CSV import with error report, JSON backup, formula-injection protection"],
                 ["Reports", "-", "Per-student report card (text)"],
                 ["Usability", "Buttons only", "Menus, shortcuts, live preview, status bar"],
                 ["Delivery", "ZIP containing __pycache__", "Clean package, build scripts for .exe, README, changelog"]],
                [3 * cm, 4.3 * cm, W - 7.3 * cm])]

    # ---- 9, 10, refs
    s += [Paragraph("9. Limitations and Future Scope", h1)]
    s += B(["Single-user and offline; a web or multi-user version would need authentication and a database such as SQLite or PostgreSQL.",
            "Subjects and the grading scale are fixed constants; a settings screen could make them configurable per course.",
            "Charts are drawn with Tkinter Canvas; Matplotlib or PDF export of charts could be added.",
            "Possible additions: semester history per student, attendance tracking, trend lines, e-mail of report cards, an installer (Inno Setup).",
            "The GUI is verified manually; GUI automation tests could be added."])
    s += [Paragraph("10. Conclusion", h1),
          P("CampusSolve Pro meets its objectives: it records and validates marks, computes grades and ranks "
            "automatically, offers meaningful class analytics and protects the data against accidental loss. "
            "The layered, tested design makes the code easy to explain, maintain and extend, and the project "
            "demonstrates practical use of file handling, GUI programming, data validation, statistics, "
            "and software-testing principles in Python."),
          Paragraph("References", h1)]
    s += B(["Python Software Foundation. <i>Python 3 Documentation</i> - tkinter, json, csv, statistics, unittest, tempfile. https://docs.python.org/3/",
            "Python Software Foundation. <i>tkinter.ttk - Tk themed widgets</i>. https://docs.python.org/3/library/tkinter.ttk.html",
            "OWASP. <i>CSV Injection</i>. https://owasp.org/www-community/attacks/CSV_Injection",
            "PyInstaller Team. <i>PyInstaller Manual</i>. https://pyinstaller.org/",
            "Martin, R. C. <i>Clean Code</i>, Prentice Hall, 2008 (separation of concerns)."])

    # ---- appendices
    s += [PageBreak(), Paragraph("Appendix A - Installation and User Guide", h1),
          table([["Step", "Instruction"],
                 ["1", "Extract CampusSolve_Pro.zip."], ["2", "Open the folder in VS Code (or any terminal)."],
                 ["3", "Run <font face='Courier'>python main.py</font> (or double-click run.bat)."],
                 ["4", "Use <i>File &gt; Load sample data</i> to see the application with 12 students."],
                 ["5", "Run <font face='Courier'>python -m unittest discover -s tests -v</font> to execute the tests."],
                 ["6", "Run build_exe.bat to create dist\\CampusSolvePro.exe."]], [1.4 * cm, W - 1.4 * cm]),
          Paragraph("Appendix B - Screenshot and Evidence Checklist", h1),
          P("Insert screenshots taken on your own machine before submission:"),
          ]
    s += B(["Main window with sample data loaded (dashboard cards and table).",
            "Add-student dialog showing the live preview; a validation error for marks above 100.",
            "Report card window for one student.",
            "Analytics dashboard: all three tabs.",
            "Terminal showing <font face='Courier'>python -m unittest discover -s tests -v</font> with all tests passing.",
            "Exported CSV opened in Excel."])

    doc = Report(path, meta)
    doc.multiBuild(s)
    return total, failed


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", default="[Your Name]")
    ap.add_argument("--roll", default="[Roll / Registration No.]")
    ap.add_argument("--course", default="[Programme / Course]")
    ap.add_argument("--institution", default="[Institution Name]")
    ap.add_argument("--guide", default="[Guide Name]")
    ap.add_argument("--out", default=os.path.join(ROOT, "docs", "CampusSolve_Pro_Project_Report.pdf"))
    a = ap.parse_args()
    t, f = build(a.out, dict(name=a.name, roll=a.roll, course=a.course, institution=a.institution, guide=a.guide))
    print(f"Report written to {a.out}  (tests: {t} run, {f} failed)")
