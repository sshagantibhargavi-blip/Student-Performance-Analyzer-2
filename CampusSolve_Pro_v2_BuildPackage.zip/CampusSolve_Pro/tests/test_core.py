"""Unit tests for campussolve.core.  Run:  python -m unittest discover -s tests -v"""
import csv
import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from campussolve import core  # noqa: E402


def make(name="Test", roll="R1", marks=(80, 80, 80, 80, 80)):
    return core.normalize_record({"name": name, "roll": roll,
                                  "marks": dict(zip(core.SUBJECTS, marks))})


class GradeTests(unittest.TestCase):
    def test_boundaries(self):
        cases = {100: "A", 90: "A", 89.99: "B", 80: "B", 79.99: "C", 70: "C",
                 69.99: "D", 60: "D", 59.99: "F", 0: "F"}
        for average, grade in cases.items():
            with self.subTest(average=average):
                self.assertEqual(core.grade_for(average), grade)


class ValidationTests(unittest.TestCase):
    def test_valid_record_is_computed(self):
        rec = make(marks=(90, 80, 70, 60, 50))
        self.assertEqual(rec["total"], 350)
        self.assertAlmostEqual(rec["average"], 70)
        self.assertEqual(rec["grade"], "C")

    def test_rejects_out_of_range_marks(self):
        for bad in (-1, 100.01, 101, 1000):
            with self.subTest(bad=bad), self.assertRaises(core.ValidationError):
                make(marks=(bad, 50, 50, 50, 50))

    def test_rejects_non_numeric_nan_inf(self):
        for bad in ("abc", "", "nan", "inf", "-inf", None):
            with self.subTest(bad=bad), self.assertRaises(core.ValidationError):
                make(marks=(bad, 50, 50, 50, 50))

    def test_boundary_marks_accepted(self):
        self.assertEqual(make(marks=(0, 0, 0, 0, 0))["grade"], "F")
        self.assertEqual(make(marks=(100,) * 5)["grade"], "A")

    def test_identity_rules(self):
        with self.assertRaises(core.ValidationError):
            make(name="   ")
        with self.assertRaises(core.ValidationError):
            make(name="x" * 61)
        with self.assertRaises(core.ValidationError):
            make(roll="")
        with self.assertRaises(core.ValidationError):
            make(roll="bad<roll>")
        self.assertEqual(make(name="  Asha  ", roll=" CS-01/A ")["name"], "Asha")

    def test_missing_subject(self):
        with self.assertRaises(core.ValidationError):
            core.normalize_record({"name": "A", "roll": "1", "marks": {"Python": 50}})

    def test_stale_derived_fields_are_recomputed(self):
        raw = {"name": "A", "roll": "1", "total": 1, "average": 1, "grade": "F",
               "marks": dict(zip(core.SUBJECTS, (100,) * 5))}
        self.assertEqual(core.normalize_record(raw)["grade"], "A")

    def test_roll_exists_is_case_insensitive(self):
        students = [make(roll="CS1")]
        self.assertTrue(core.roll_exists(students, "cs1"))
        self.assertFalse(core.roll_exists(students, "cs1", exclude=students[0]))
        self.assertFalse(core.roll_exists(students, "cs2"))


class AnalyticsTests(unittest.TestCase):
    def test_ranking_with_ties(self):
        a, b, c, d = make("A", "1", (90,) * 5), make("B", "2", (80,) * 5), \
            make("C", "3", (80,) * 5), make("D", "4", (50,) * 5)
        ranks = [(r, s["name"]) for r, s in core.rank_students([d, c, b, a])]
        self.assertEqual(ranks, [(1, "A"), (2, "B"), (2, "C"), (4, "D")])

    def test_empty_class_summary(self):
        summary = core.class_summary([])
        self.assertEqual(summary["count"], 0)
        self.assertIsNone(summary["topper"])

    def test_class_summary_values(self):
        students = [make("A", "1", (100,) * 5), make("B", "2", (50,) * 5)]
        summary = core.class_summary(students)
        self.assertEqual(summary["count"], 2)
        self.assertAlmostEqual(summary["average"], 75)
        self.assertAlmostEqual(summary["median"], 75)
        self.assertAlmostEqual(summary["std_dev"], 25)
        self.assertEqual(summary["highest"], 100)
        self.assertEqual(summary["lowest"], 50)
        self.assertEqual(summary["pass_rate"], 50)
        self.assertEqual(summary["topper"], "A")

    def test_subject_stats(self):
        students = [make("A", "1", (100, 80, 60, 40, 20)), make("B", "2", (50, 80, 60, 40, 20))]
        stats = core.subject_stats(students)
        self.assertEqual(stats["Python"]["average"], 75)
        self.assertEqual(stats["Python"]["highest"], 100)
        self.assertEqual(stats["Python"]["lowest"], 50)
        self.assertEqual(stats["Chemistry"]["pass_rate"], 0)
        self.assertEqual(stats["English"]["pass_rate"], 100)

    def test_grade_distribution_has_all_grades(self):
        dist = core.grade_distribution([make("A", "1", (95,) * 5)])
        self.assertEqual(dist, {"A": 1, "B": 0, "C": 0, "D": 0, "F": 0})

    def test_needs_attention(self):
        self.assertFalse(core.needs_attention(make(marks=(85,) * 5)))
        self.assertTrue(core.needs_attention(make(marks=(65,) * 5)))          # grade D
        self.assertTrue(core.needs_attention(make(marks=(100, 100, 100, 100, 30))))  # failed subject

    def test_insights(self):
        students = [make("A", "1", (100, 90, 80, 70, 60)), make("B", "2", (50,) * 5)]
        info = core.student_insights(students[0], students)
        self.assertEqual(info["rank"], 1)
        self.assertEqual(info["best_subject"], "Python")
        self.assertEqual(info["weakest_subject"], "Chemistry")
        self.assertGreater(info["vs_class"]["Python"], 0)

    def test_report_card_contains_key_facts(self):
        students = core.sample_students()
        text = core.report_card_text(students[0], students)
        for needle in ("Aarav Sharma", "CS101", "Rank", "Grade", "Remark"):
            self.assertIn(needle, text)


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, "students.json")
        self.store = core.StudentStore(self.path)

    def tearDown(self):
        self.tmp.cleanup()

    def test_missing_file_gives_empty_list(self):
        self.assertEqual(self.store.load(), [])

    def test_save_load_roundtrip_and_no_temp_leftovers(self):
        data = core.sample_students()
        self.store.save(data)
        self.assertEqual(self.store.load(), data)
        self.assertEqual([f for f in os.listdir(self.tmp.name) if f.endswith(".tmp")], [])

    def test_second_save_creates_backup(self):
        self.store.save([make()])
        self.store.save([make(), make("B", "R2")])
        self.assertTrue(os.path.exists(self.path + ".bak"))
        with open(self.path + ".bak", encoding="utf-8") as handle:
            self.assertEqual(len(json.load(handle)), 1)

    def test_corrupt_json_raises_and_can_be_quarantined(self):
        with open(self.path, "w", encoding="utf-8") as handle:
            handle.write("{ not json")
        with self.assertRaises(core.DataFileError):
            self.store.load()
        copy = self.store.quarantine()
        self.assertTrue(copy and os.path.exists(copy))

    def test_duplicate_rolls_rejected(self):
        with open(self.path, "w", encoding="utf-8") as handle:
            json.dump([make(roll="A"), make(roll="a")], handle)
        with self.assertRaises(core.DataFileError):
            self.store.load()

    def test_legacy_file_with_wrong_derived_values_is_fixed(self):
        legacy = [{"name": "Old", "roll": "9", "total": 0, "average": 0, "grade": "F",
                   "marks": dict(zip(core.SUBJECTS, (90, 90, 90, 90, 90)))}]
        with open(self.path, "w", encoding="utf-8") as handle:
            json.dump(legacy, handle)
        self.assertEqual(self.store.load()[0]["grade"], "A")


class CsvTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, "r.csv")

    def tearDown(self):
        self.tmp.cleanup()

    def test_export_then_import_roundtrip(self):
        data = core.sample_students()
        core.export_csv(self.path, data)
        records, errors = core.import_csv(self.path)
        self.assertEqual(errors, [])
        self.assertEqual({r["roll"] for r in records}, {s["roll"] for s in data})

    def test_export_neutralises_formula_injection(self):
        core.export_csv(self.path, [make(name="=HYPERLINK(\"x\")", roll="-1")])
        with open(self.path, encoding="utf-8-sig") as handle:
            row = list(csv.reader(handle))[1]
        self.assertTrue(row[1].startswith("'="))
        self.assertTrue(row[2].startswith("'-"))

    def test_import_reports_bad_rows_but_keeps_good_ones(self):
        with open(self.path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(["Name", "Roll No"] + core.SUBJECTS)
            writer.writerow(["Good", "1", 80, 80, 80, 80, 80])
            writer.writerow(["Bad marks", "2", 120, 80, 80, 80, 80])
            writer.writerow(["Dup", "1", 70, 70, 70, 70, 70])
            writer.writerow([])
            writer.writerow(["Short row", "3", 50])
        records, errors = core.import_csv(self.path)
        self.assertEqual([r["roll"] for r in records], ["1"])
        self.assertEqual(len(errors), 3)

    def test_import_missing_columns(self):
        with open(self.path, "w", encoding="utf-8") as handle:
            handle.write("Name,Roll\nA,1\n")
        records, errors = core.import_csv(self.path)
        self.assertEqual(records, [])
        self.assertIn("Missing required column", errors[0])

    def test_import_missing_file(self):
        records, errors = core.import_csv(os.path.join(self.tmp.name, "nope.csv"))
        self.assertEqual(records, [])
        self.assertTrue(errors)


class SampleDataTests(unittest.TestCase):
    def test_sample_data_is_valid_and_diverse(self):
        students = core.sample_students()
        self.assertEqual(len(students), 12)
        self.assertEqual(len({s["roll"] for s in students}), 12)
        self.assertGreaterEqual(len({s["grade"] for s in students}), 4)


if __name__ == "__main__":
    unittest.main(verbosity=2)
