# CampusSolve Pro v2.0 - Student Performance Analyzer

A desktop application (Python + Tkinter + JSON + CSV) for recording student marks and analysing
academic performance. **No third-party packages are needed to run it.**

## Quick start (Windows / VS Code)
1. Extract the ZIP and open the `CampusSolve_Pro` folder in VS Code.
2. Open a terminal and run `python main.py` (or double-click `run.bat`).
3. Want instant demo data? Use **File > Load sample data** (12 students).

Requires Python 3.10+ with Tkinter (included in the standard python.org Windows installer).

## Features
| Area | What you get |
|---|---|
| Records | Add / edit / delete with validation (name, unique roll number, marks 0-100, NaN/inf rejected), live total-average-grade preview |
| Safety | Atomic JSON saves, automatic `.bak` copy, corrupt-file quarantine, **Undo (Ctrl+Z)** for the last 20 changes |
| Table | Click-to-sort columns, search by name/roll, grade filter, "Needs attention" filter, colour-coded grades |
| Analytics | Dashboard cards, subject-average chart, grade-distribution chart, median, standard deviation, per-subject pass rate |
| Ranking | Competition ranking with ties (1, 2, 2, 4) |
| Reports | Per-student report card (rank, strongest/weakest subject, comparison with class, remark) saved as `.txt` |
| Data exchange | CSV **import** with row-level error report, ranked CSV **export** (protected against spreadsheet formula injection), JSON backup |
| Extras | Menu bar, keyboard shortcuts, grading-scale help, command-line summary `python main.py --summary` |

## Grading scale
A 90-100 | B 80-89.99 | C 70-79.99 | D 60-69.99 | F below 60.
Pass = any grade except F. A subject mark below 40 counts as a failed subject.
*Confirm this scale matches your faculty's rules before submission.*

## Project layout
```
CampusSolve_Pro/
  main.py                 entry point (GUI or --summary)
  campussolve/core.py     business logic - validation, ranking, statistics, storage, CSV (no GUI code)
  campussolve/gui.py      Tkinter interface
  tests/test_core.py      29 unit tests
  sample_data/            demo students, CSV import template
  docs/                   project report (PDF) + generator script
  build_exe.bat / .sh     create a stand-alone executable with PyInstaller
  make_release.py         create a clean distributable ZIP
```

## Run the tests
```
python -m unittest discover -s tests -v
```

## Build a stand-alone .exe (Windows)
Double-click `build_exe.bat` (installs PyInstaller, then builds `dist\CampusSolvePro.exe`).
The executable keeps `students.json` next to itself.

## Demonstration checklist (viva / presentation)
1. File > Load sample data. Show the dashboard cards.
2. Sort by Average, filter "Needs attention", search "CS10".
3. Add a student - point out the live preview; try marks of 120 to show validation.
4. Edit marks and show the grade change; delete a student, then press **Ctrl+Z**.
5. Open Report card, Rankings and Analytics (all three tabs).
6. Export CSV and open it in Excel; import `sample_data/import_template.csv`.
7. Close and reopen to show persistence; run `python -m unittest` to show passing tests.
