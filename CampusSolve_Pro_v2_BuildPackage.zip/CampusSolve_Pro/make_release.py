"""Create a clean, distributable ZIP of the project (the "build package").

    python make_release.py

Output: dist/CampusSolve_Pro_v<version>.zip  (no __pycache__, no personal students.json)
"""
import os
import zipfile

from campussolve import __version__

ROOT = os.path.dirname(os.path.abspath(__file__))
SKIP_DIRS = {"__pycache__", "dist", "build", ".git", ".vscode"}
SKIP_FILES = {"students.json", "students.json.bak"}
SKIP_SUFFIX = (".pyc", ".tmp", ".spec")


def main():
    os.makedirs(os.path.join(ROOT, "dist"), exist_ok=True)
    target = os.path.join(ROOT, "dist", f"CampusSolve_Pro_v{__version__}.zip")
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as bundle:
        for folder, dirs, files in os.walk(ROOT):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for name in files:
                if name in SKIP_FILES or name.endswith(SKIP_SUFFIX) or ".corrupt-" in name:
                    continue
                full = os.path.join(folder, name)
                bundle.write(full, os.path.join("CampusSolve_Pro", os.path.relpath(full, ROOT)))
    print("Created", target)


if __name__ == "__main__":
    main()
