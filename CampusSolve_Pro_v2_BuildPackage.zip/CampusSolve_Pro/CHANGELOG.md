# Changelog

## 2.0.0
- Split the single 302-line `main.py` into `core.py` (logic), `gui.py` (interface) and an entry point.
- Added 29 automated unit tests.
- New: undo, column sorting, grade/attention filter, CSV import, JSON backup, report cards,
  analytics dashboard (grade distribution, median, std-dev, per-subject pass rate), menus and shortcuts.
- Ranking now handles ties correctly.
- Stricter validation: NaN/inf marks, name length, roll-number format.
- Data safety: `.bak` copy on every save, corrupt `students.json` is quarantined, save failures roll back.
- CSV export hardened against spreadsheet formula injection.
- Removed the stray `__pycache__` folder from the package; added build scripts for a Windows .exe.

## 1.0.0
- Original single-file prototype.
