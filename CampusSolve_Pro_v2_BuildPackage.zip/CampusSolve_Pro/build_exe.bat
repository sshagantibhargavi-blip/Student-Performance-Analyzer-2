@echo off
REM Builds a single-file Windows executable: dist\CampusSolvePro.exe
cd /d "%~dp0"
python -m pip install --upgrade pyinstaller
python -m PyInstaller --noconfirm --clean --onefile --windowed --name CampusSolvePro main.py
echo.
echo Done. Your program is in the "dist" folder: dist\CampusSolvePro.exe
echo students.json is created next to the .exe on first save.
pause
